#include "calculatorserver.h"

CalculatorServer::CalculatorServer(QObject *parent) : CalculatorSimpleSource(parent)
{

}

int CalculatorServer::add(int x, int y)
{
//    int sum = 0;
//    for(int i = 0; i < 100000; i++)
//    {
//        if(i %  2 == 0){
//            sum += x;
//        }else {
//            sum += y;
//        }
//    }
//    return sum;

    return x+y;
}
