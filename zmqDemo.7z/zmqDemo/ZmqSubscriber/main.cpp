#include <iostream>
#include "zmq.hpp"

using namespace std;
using namespace zmq;

int main()
{
    context_t ctx;
    socket_t subscriber(ctx, socket_type::sub);
    subscriber.setsockopt(ZMQ_SUBSCRIBE, "", 0);
    int timeout = 1000;
    subscriber.setsockopt(ZMQ_RCVTIMEO, &timeout, sizeof(int));
    subscriber.connect("tcp://localhost:3000");
    char* buffer = new char[1024];
    while (true)
    {
        int size = subscriber.recv(buffer, sizeof(int));
        std::cout << "Size: " << size << endl;
        if(size > 0)
        {
            int* data = reinterpret_cast<int*>(buffer);
            std::cout << "Receive: " << *data << endl;
        }
    }
    return 0;
}
