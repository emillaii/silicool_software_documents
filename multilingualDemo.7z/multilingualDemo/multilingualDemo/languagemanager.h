#ifndef LANGUAGEMANAGER_H
#define LANGUAGEMANAGER_H

#include <QObject>
#include <QGuiApplication>
#include <QQmlApplicationEngine>


class LanguageManager:public QObject
{
    Q_OBJECT

public:
    LanguageManager(QGuiApplication& app, QQmlApplicationEngine& engine);
    Q_INVOKABLE void switchLanguage(int lan);

private:
    QGuiApplication& app;
    QQmlApplicationEngine& engine;
};

#endif // LANGUAGEMANAGER_H
