#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QRemoteObjectNode>
#include <QQmlContext>
#include <QElapsedTimer>
#include "../Utilities/loging/loging.h"
//#include "rep_vision_replica.h"
#include "../Utilities/loghelper.h"
#include "../Utilities/configManager/configmanagerunittest.h"
#include "../Utilities/configManager/configfile.h"
#include "../Utilities/configManager/qobjectfactory.h"



int main(int argc, char *argv[])
{
    QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);

    QGuiApplication app(argc, argv);

    QQmlApplicationEngine engine;

    // initialize logging system
    LogConfig logConfig;
    ConfigFile logConfigFile("logConfig", &logConfig, "logConfig");
    logConfigFile.populate();
    LogManager logManager;
    logManager.initLogSystem(&logConfig);
    engine.rootContext()->setContextProperty("logConfig", &logConfig);
    engine.rootContext()->setContextProperty("logModel", &logManager.logModel);

    QObjectFactory::registerClass<TestClassA>();
    QObjectFactory::registerClass<TestClassB>();
    QObjectFactory::registerClass<TestClassE>();

    qmlRegisterType<ConfigElementInfo>("ConfigElementType", 1, 0, "ConfigElementType");
    qmlRegisterType<ConfigObject>("ConfigObject", 1, 0, "ConfigObject");
    qRegisterMetaType<ConfigElementInfo::Type>();

    TestClassB testClassB;
    testClassB.setObjectName("testClassB");
    ConfigFile testClassBConfigFile("testClassB", &testClassB, "testClassB.json");
    testClassBConfigFile.populate();
    engine.rootContext()->setContextProperty("testClassB", &testClassB);

    TestClassC testClassC;
    testClassC.setObjectName("testClassC");
    ConfigFile testClassCConfigFile("testClassC", &testClassC, "testClassC.json");
    testClassCConfigFile.populate();
    engine.rootContext()->setContextProperty("testClassC", &testClassC);

    TestClassD testClassD;
    testClassD.setObjectName("testClassD");
    ConfigFile testClassDConfigFile("testClassD", &testClassD, "testClassD.json");
    testClassDConfigFile.populate();
    engine.rootContext()->setContextProperty("testClassD", &testClassD);

    ConfigObjectArray testClassEArray("TestClassE");
    testClassEArray.setObjectName("testClassEArray");
    ConfigFile testClassEArrayConfigFile("testClassEArray", &testClassEArray, "testClassEArray.json");
    testClassEArrayConfigFile.populate();
    engine.rootContext()->setContextProperty("testClassEArray", &testClassEArray);

    ConfigArray intArray(ConfigElementInfo::Int);
    intArray.setObjectName("intArray");
    ConfigFile intArrayConfigFile("intArray", &intArray, "intArray.json");
    intArrayConfigFile.populate();
    engine.rootContext()->setContextProperty("intArray", &intArray);
    QVariantList intOptions;
    for(int i = 10; i < 20; i++)
    {
        intOptions.append(i);
    }
    intArray.setOptionalProperty(intOptions);

    engine.rootContext()->setContextProperty("configManager", &SI::cfgManager);

    const QUrl url(QStringLiteral("qrc:/qml/main.qml"));
    QObject::connect(&engine, &QQmlApplicationEngine::objectCreated,
                     &app, [url](QObject *obj, const QUrl &objUrl) {
        if (!obj && url == objUrl)
            QCoreApplication::exit(-1);
    }, Qt::QueuedConnection);
    engine.load(url);

    int result = app.exec();
    logManager.disposeLogSystem();
    return result;
}
