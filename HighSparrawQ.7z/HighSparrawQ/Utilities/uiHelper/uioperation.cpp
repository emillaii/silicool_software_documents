#include "uioperation.h"


UIOperation::UIOperation()
{
    yesNoButtons.append(Yes);
    yesNoButtons.append(No);
    passFailButtons.append(Pass);
    passFailButtons.append(Fail);
    okCancelButtons.append(Ok);
    okCancelButtons.append(Cancel);
}

void UIOperation::init(MsgBoxModel *msgBoxModel)
{
    this->msgBoxModel = msgBoxModel;
    connect(this, &UIOperation::addMsgBox, msgBoxModel, &MsgBoxModel::onAddMsgBox);
    connect(this, &UIOperation::removeMsgBox, msgBoxModel, &MsgBoxModel::onRemoveMsgBox);
}

void UIOperation::showMessage(QString title, QString content, MsgBoxIcon::Icon icon, QList<QString> buttons)
{
    getLogger(icon) << QString("showMessage, title: %1, content: %2").arg(title).arg(content);

    QString uuid = QUuid::createUuid().toString();
    MsgBoxItem msgBox(uuid, title, icon, content, buttons);
    emit addMsgBox(msgBox);
}

void UIOperation::showMessage(QString title, QString content, MsgBoxIcon::Icon icon, QString button)
{
    QList<QString> buttons;
    buttons.append(button);
    showMessage(title, content, icon, buttons);
}

QString UIOperation::getUIResponse(QString title, QString content, MsgBoxIcon::Icon icon, QList<QString> buttons)
{
    auto logger = getLogger(icon);
    logger << QString("getUIResponse, title: %1, content: %2, buttons: %3")
              .arg(title).arg(content).arg(CommonMethod::combineString("|", buttons));

    QString uuid = QUuid::createUuid().toString();
    MsgBoxItem msgBox(uuid, title, icon, content, buttons);
    UIResponse* rsp = new UIResponse;
    uiRsp[uuid] = rsp;
    emit addMsgBox(msgBox);
    QMutex locker;
    locker.lock();
    rsp->waitResponse.wait(&locker);
    locker.unlock();
    uiRsp.remove(uuid);
    QString clickedButton = rsp->clickedButton;
    delete rsp;

    logger << QString("getUIResponse, user clicked button: %1").arg(clickedButton);
    return clickedButton;
}

QString UIOperation::getUIResponse(QString title, QString content, MsgBoxIcon::Icon icon, QString button)
{
    QList<QString> buttons;
    buttons.append(button);
    return getUIResponse(title, content, icon, buttons);
}

void UIOperation::onUIResponse(QString uuid, QString clickedButton)
{
    emit removeMsgBox(uuid);
    if(uiRsp.contains(uuid))
    {
        uiRsp[uuid]->clickedButton = clickedButton;
        uiRsp[uuid]->waitResponse.wakeOne();
    }
}
