#include "threadtest.h"

ThreadTest::ThreadTest():QObject()
{
    connect(this, &ThreadTest::initSignal, this, &ThreadTest::onInit);
    connect(this, &ThreadTest::testSignal, this, &ThreadTest::onTest);
}
