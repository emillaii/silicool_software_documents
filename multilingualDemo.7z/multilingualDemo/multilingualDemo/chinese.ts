<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN">
<context>
    <name>Page1Form.ui</name>
    <message>
        <location filename="Page1Form.ui.qml" line="9"/>
        <source>中文</source>
        <translation></translation>
    </message>
    <message>
        <location filename="Page1Form.ui.qml" line="13"/>
        <source>English</source>
        <translation></translation>
    </message>
    <message>
        <location filename="Page1Form.ui.qml" line="18"/>
        <source>Lable</source>
        <translation>标签</translation>
    </message>
    <message>
        <location filename="Page1Form.ui.qml" line="21"/>
        <source>text</source>
        <translation>文本</translation>
    </message>
    <message>
        <location filename="Page1Form.ui.qml" line="24"/>
        <source>修改</source>
        <translation></translation>
    </message>
    <message>
        <location filename="Page1Form.ui.qml" line="27"/>
        <source>添加</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>Page2Form.ui</name>
    <message>
        <location filename="Page2Form.ui.qml" line="6"/>
        <source>Hello!</source>
        <translation>你好！</translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <location filename="main.qml" line="10"/>
        <source>Hello World</source>
        <translation>世界你好</translation>
    </message>
</context>
</TS>
