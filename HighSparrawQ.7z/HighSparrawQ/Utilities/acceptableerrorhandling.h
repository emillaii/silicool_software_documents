#ifndef ACCEPTABLEERRORHANDLING_H
#define ACCEPTABLEERRORHANDLING_H

#include <QtCore>

class AcceptableErrorHandling
{
public:
    AcceptableErrorHandling()
    {
        retryIgnoreAbortButtons.append(Retry);
        retryIgnoreAbortButtons.append(Ignore);
        retryIgnoreAbortButtons.append(Abort);
        retryAbortButtons.append(Retry);
        retryAbortButtons.append(Abort);
        retryIgnoreButtons.append(Retry);
        retryIgnoreButtons.append(Ignore);
    }

public:
    const QString Retry = "Retry";
    const QString Ignore = "Ignore";
    const QString Abort = "Abort";

    QList<QString> retryIgnoreAbortButtons;
    QList<QString> retryAbortButtons;
    QList<QString> retryIgnoreButtons;
};

#endif // ACCEPTABLEERRORHANDLING_H
