#include "singletoninstances.h"

UIOperation SI::ui;
AcceptableErrorHandling SI::aeh;
ConfigManager SI::cfgManager;
