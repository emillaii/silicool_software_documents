#include <iostream>
#include "zmq.hpp"

using namespace std;

int main()
{
    zmq::context_t ctx;
    zmq::socket_t publisher(ctx, zmq::socket_type::pub);
    publisher.bind("tcp://*:3000");
    int i = 0;
    while (true)
    {
        zmq::message_t msg(&i, sizeof(i));
        publisher.send(msg);
        i++;
        Sleep(500);
        cout << "Send: " << i << endl;
    }
    return 0;
}
