#include "test.h"

Test::Test(QObject *parent) : QObject(parent)
{

}

void Test::init(CalculatorReplica *calculator)
{
    this->calc = calculator;
}

void Test::onTest()
{
    int times = 10;
    double* timecost = new double[times];
    int sum = 0;
    QElapsedTimer timer;
    for(int i = 0; i < times; i++)
    {
        sum = 0;
        timer.restart();
        for(int j = 0; j < 100; j++)
        {
            sum += calc->add(i, j);
        }
        timecost[i] = timer.elapsed();
        qDebug() << "Num: " << i+1 << " times: " << timecost[i] << " sum: " << sum;
        QThread::msleep(50);
    }

    double totalTime = 0;
    for(int i = 0; i < times; i++)
    {
        totalTime += timecost[i];
    }
    qDebug() << "Average: " << totalTime / times;

}
