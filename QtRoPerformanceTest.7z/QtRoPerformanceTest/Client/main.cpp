#include <QCoreApplication>
#include <QElapsedTimer>
#include <qthread.h>
#include "./rep_calculator_replica.h"

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    QRemoteObjectNode node;
    if(!node.connectToNode(QUrl("local:calcServer")))
    {
        qDebug("Connect to server failed!");
    }
    auto calc = node.acquire<CalculatorReplica>();

    qDebug() << "is init: " << calc->isInitialized();
    qDebug() << "is valid: " << calc->isReplicaValid();
    qDebug() << "state: " << calc->state();


    int times = 10;
    double* timecost = new double[times];
    int sum = 0;
    QElapsedTimer timer;
    for(int i = 0; i < times; i++)
    {
        sum = 0;
        timer.restart();
        for(int j = 0; j < 1; j++)
        {
            sum += calc->add(i, j);
        }
        timecost[i] = timer.elapsed();
        qDebug() << "Num: " << i+1 << " timecost: " << timecost[i] << " sum: " << sum;
    }

    double totalTime = 0;
    for(int i = 0; i < times; i++)
    {
        totalTime += timecost[i];
    }
    qDebug() << "Average: " << totalTime / times;


    return a.exec();
}
