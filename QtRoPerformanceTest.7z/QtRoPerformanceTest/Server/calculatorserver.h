#ifndef CALCULATORSERVER_H
#define CALCULATORSERVER_H

#include <QObject>
#include "./rep_calculator_source.h"

class CalculatorServer : public CalculatorSimpleSource
{
    Q_OBJECT
public:
    explicit CalculatorServer(QObject *parent = nullptr);

signals:

public slots:

    // CalculatorSource interface
public slots:
    virtual int add(int x, int y) override;
};

#endif // CALCULATORSERVER_H
