#ifndef SILICOLERROR_H
#define SILICOLERROR_H

#include <exception>
#include "commonmethod.h"
#include "singletoninstances.h"
#include <excpt.h>


class SilicolError: public std::exception
{
public:
    SilicolError(QString moduleName, QString errorMsg, QString acceptableErrorHandling, QString suggestion=nullptr):
        moduleName(moduleName), errorMsg(errorMsg), suggestion(suggestion),
        represent(moduleName + " Error.\r\nError message: " + errorMsg
                  + "\r\nAcceptable Error Handling: " + acceptableErrorHandling
                  + (suggestion == nullptr ? "" : "\r\nSuggestion: " + suggestion))
    {
        this->acceptableErrorHandlings.append(acceptableErrorHandling);
    }

    SilicolError(QString moduleName, QString errorMsg, QList<QString> acceptableErrorHandlings, QString suggestion=nullptr):
        moduleName(moduleName), errorMsg(errorMsg), acceptableErrorHandlings(acceptableErrorHandlings), suggestion(suggestion),
        represent(moduleName + " Error.\r\nError message: " + errorMsg
                  + "\r\nAcceptable Error Handling: "
                  + CommonMethod::combineString(",", acceptableErrorHandlings)
                  + (suggestion == nullptr ? "" : "\r\nSuggestion: " + suggestion))
    {

    }

public:
    QString moduleName;
    QString errorMsg;
    QList<QString> acceptableErrorHandlings;
    QString suggestion=nullptr;
    QString represent;

    // exception interface
public:
    virtual const char *what() const override
    {
        return represent.toStdString().c_str();
    }
};


class SilicolAbort: public std::exception
{
public:
    SilicolAbort(QString abortMsg): abortMsg(abortMsg)
    {

    }

public slots:


public:
    QString abortMsg;

    // exception interface
public:
    virtual const char *what() const override
    {
        return abortMsg.toStdString().c_str();
    }
};


class Test
{
    void test()
    {
        while(true)
        {
            try{





            }catch(SilicolError& se){
                QString title = se.moduleName + " Error";
                QString content = se.errorMsg;
                if (se.suggestion != nullptr) {
                    content += "\r\nSuggestion: " + se.suggestion;
                }
                auto errHandling = SI::ui.getUIResponse(title, content, MsgBoxIcon::Error, se.acceptableErrorHandlings);
                if (errHandling == SI::aeh.Abort) {
                    throw SilicolAbort("User selected abort!");
                }else if (errHandling == SI::aeh.Ignore) {
                    qWarning("User selected ignore!");
                    return;
                }else if (errHandling == SI::aeh.Retry) {
                    continue;
                }else {
                    throw SilicolAbort(QString("Unknown error handling: %1").arg(errHandling));
                }

            }
        }
    }
};

#endif // SILICOLERROR_H

