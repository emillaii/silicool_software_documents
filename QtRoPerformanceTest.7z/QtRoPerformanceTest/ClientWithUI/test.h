#ifndef TEST_H
#define TEST_H

#include <QObject>
#include "./rep_calculator_replica.h"
#include <QElapsedTimer>
#include <qthread.h>

class TTT: public QObject
{
    Q_OBJECT

public:
    Q_INVOKABLE void test()
    {
        emit startTest();
    }

signals:
    void startTest();
};

class Test : public QObject
{
    Q_OBJECT
public:
    explicit Test(QObject *parent = nullptr);

    void init(CalculatorReplica* calculator);



public slots:
    void onTest();

private:
    CalculatorReplica* calc;
};

#endif // TEST_H
