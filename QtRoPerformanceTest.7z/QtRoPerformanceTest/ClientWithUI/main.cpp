#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include <qthread.h>
#include "test.h"
#include "threadtest.h"

int main(int argc, char *argv[])
{
    QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);

    QGuiApplication app(argc, argv);

    QQmlApplicationEngine engine;

    QRemoteObjectNode node;
    if(!node.connectToNode(QUrl("local:calcServer")))
    {
        qDebug("Connect to server failed!");
    }
    auto calc = node.acquire<CalculatorReplica>();

    Test test;
    test.init(calc);
    QThread thd;
    test.moveToThread(&thd);
    thd.start();
    TTT ttt;
    ttt.connect(&ttt, &TTT::startTest, &test, &Test::onTest);
    engine.rootContext()->setContextProperty("ttt", &ttt);
    engine.rootContext()->setContextProperty("calc", calc);



    //    ThreadTest thdTest;
    //    QThread thd;
    //    thdTest.moveToThread(&thd);
    //    thd.start();

    //    thdTest.init();

    //    TTT ttt;
    //    ttt.connect(&ttt, &TTT::startTest, &thdTest, &ThreadTest::onTest);
    //    engine.rootContext()->setContextProperty("ttt", &ttt);

    const QUrl url(QStringLiteral("qrc:/main.qml"));
    QObject::connect(&engine, &QQmlApplicationEngine::objectCreated,
                     &app, [url](QObject *obj, const QUrl &objUrl) {
        if (!obj && url == objUrl)
            QCoreApplication::exit(-1);
    }, Qt::QueuedConnection);
    engine.load(url);

    return app.exec();
}
